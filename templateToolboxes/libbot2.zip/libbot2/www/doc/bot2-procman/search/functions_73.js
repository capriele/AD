var searchData=
[
  ['save_5fconfig',['save_config',['../classbot__procman_1_1sheriff_1_1Sheriff.html#ab8cc18c368b12aaaff34008a159c16d4',1,'bot_procman::sheriff::Sheriff']]],
  ['schedule_5fcommand_5ffor_5fremoval',['schedule_command_for_removal',['../classbot__procman_1_1sheriff_1_1Sheriff.html#a7b9750dc2a17052edec129f7841ce3ee',1,'bot_procman::sheriff::Sheriff']]],
  ['send_5forders',['send_orders',['../classbot__procman_1_1sheriff_1_1Sheriff.html#aff5bb1da6e34f5528dad7cf7d95f5ecf',1,'bot_procman::sheriff::Sheriff']]],
  ['set_5fauto_5frespawn',['set_auto_respawn',['../classbot__procman_1_1sheriff_1_1Sheriff.html#ac8a30bf0691114fcef80c18d8cf65282',1,'bot_procman::sheriff::Sheriff']]],
  ['set_5fcommand_5fexec',['set_command_exec',['../classbot__procman_1_1sheriff_1_1Sheriff.html#a48f941e52ff14bbe079845952f0ea67c',1,'bot_procman::sheriff::Sheriff']]],
  ['set_5fcommand_5fgroup',['set_command_group',['../classbot__procman_1_1sheriff_1_1Sheriff.html#a5a50739c97fa09c7a599b926f1c6ae7e',1,'bot_procman::sheriff::Sheriff']]],
  ['set_5fcommand_5fid',['set_command_id',['../classbot__procman_1_1sheriff_1_1Sheriff.html#ac0aad034f4571659153728c7fba8dd1d',1,'bot_procman::sheriff::Sheriff']]],
  ['set_5fcommand_5fstop_5fsignal',['set_command_stop_signal',['../classbot__procman_1_1sheriff_1_1Sheriff.html#aa9e47bd02b839a65daf8de78fc935211',1,'bot_procman::sheriff::Sheriff']]],
  ['set_5fcommand_5fstop_5ftime_5fallowed',['set_command_stop_time_allowed',['../classbot__procman_1_1sheriff_1_1Sheriff.html#a9f14fb663b50c7b9746d8ee06bbdd12d',1,'bot_procman::sheriff::Sheriff']]],
  ['set_5fobserver',['set_observer',['../classbot__procman_1_1sheriff_1_1Sheriff.html#a71c74b3794ea8bfb3544a66873999db6',1,'bot_procman::sheriff::Sheriff']]],
  ['start_5fcommand',['start_command',['../classbot__procman_1_1sheriff_1_1Sheriff.html#a74ef75f97144cafbc00c761a7adf9cd2',1,'bot_procman::sheriff::Sheriff']]],
  ['status',['status',['../classbot__procman_1_1sheriff_1_1SheriffDeputyCommand.html#a8018b619b2d2ab11d6de79dd73511de9',1,'bot_procman::sheriff::SheriffDeputyCommand']]],
  ['stop_5fcommand',['stop_command',['../classbot__procman_1_1sheriff_1_1Sheriff.html#ab166c0430ed8c7fe2e5b5031946ba410',1,'bot_procman::sheriff::Sheriff']]]
];

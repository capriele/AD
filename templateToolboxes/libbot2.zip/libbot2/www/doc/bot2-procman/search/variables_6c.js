var searchData=
[
  ['last_5fupdate_5futime',['last_update_utime',['../classbot__procman_1_1sheriff_1_1SheriffDeputy.html#a7b89cc263a279bfe170ef3ec5fcac7bc',1,'bot_procman::sheriff::SheriffDeputy']]]
];

var searchData=
[
  ['sheriff',['sheriff',['../namespacebot__procman_1_1sheriff.html',1,'bot_procman']]]
];

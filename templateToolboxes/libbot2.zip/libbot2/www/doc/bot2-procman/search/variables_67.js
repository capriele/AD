var searchData=
[
  ['group',['group',['../classbot__procman_1_1sheriff_1_1SheriffDeputyCommand.html#ae91a5bfccb10df4b6a052a223d31701e',1,'bot_procman::sheriff::SheriffDeputyCommand']]],
  ['group_5fname',['group_name',['../classbot__procman_1_1sheriff_1_1SheriffCommandSpec.html#ae79328e754bf3cdfe83a5a96e41be56d',1,'bot_procman::sheriff::SheriffCommandSpec']]]
];

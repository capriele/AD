var searchData=
[
  ['update_5ffrom_5fdeputy_5finfo',['update_from_deputy_info',['../group__python__api.html#ga7222f48e7e58d2a1651fa2ac76636bfb',1,'bot_procman::sheriff::SheriffDeputy']]]
];

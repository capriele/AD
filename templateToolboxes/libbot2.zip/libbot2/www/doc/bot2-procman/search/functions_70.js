var searchData=
[
  ['purge_5fuseless_5fdeputies',['purge_useless_deputies',['../classbot__procman_1_1sheriff_1_1Sheriff.html#aa61147294212787d4febb2cd8711f60c',1,'bot_procman::sheriff::Sheriff']]]
];

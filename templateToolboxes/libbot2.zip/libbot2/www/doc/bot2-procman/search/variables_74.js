var searchData=
[
  ['trying_5fto_5fstart',['TRYING_TO_START',['../group__python__api.html#ga37be3df2dfeb12cc8863c9ecb1d65721',1,'bot_procman::sheriff']]],
  ['trying_5fto_5fstop',['TRYING_TO_STOP',['../group__python__api.html#ga861408bd3029139d620096ad4e4cbef4',1,'bot_procman::sheriff']]]
];

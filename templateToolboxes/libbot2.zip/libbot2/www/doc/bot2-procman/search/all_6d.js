var searchData=
[
  ['mem_5frss_5fbytes',['mem_rss_bytes',['../classbot__procman_1_1sheriff_1_1SheriffDeputyCommand.html#a320408c928648f5849924949cf6b0ee0',1,'bot_procman::sheriff::SheriffDeputyCommand']]],
  ['mem_5fvsize_5fbytes',['mem_vsize_bytes',['../classbot__procman_1_1sheriff_1_1SheriffDeputyCommand.html#ada15fe04eeeb48d21a7edc242841e436',1,'bot_procman::sheriff::SheriffDeputyCommand']]],
  ['move_5fcommand_5fto_5fdeputy',['move_command_to_deputy',['../classbot__procman_1_1sheriff_1_1Sheriff.html#a3ac148220e1ea218b40edc12b17bd9ff',1,'bot_procman::sheriff::Sheriff']]]
];

var searchData=
[
  ['unknown',['UNKNOWN',['../group__python__api.html#gab20563375ee81c55836648f03b174bf5',1,'bot_procman::sheriff']]],
  ['updated_5ffrom_5finfo',['updated_from_info',['../classbot__procman_1_1sheriff_1_1SheriffDeputyCommand.html#a44f5240ad621d032f7cbf12eff29ae04',1,'bot_procman::sheriff::SheriffDeputyCommand']]]
];

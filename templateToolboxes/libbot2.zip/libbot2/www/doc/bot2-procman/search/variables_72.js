var searchData=
[
  ['removing',['REMOVING',['../group__python__api.html#ga8c020179bfb021846a3100ef280d9f8f',1,'bot_procman::sheriff']]],
  ['restarting',['RESTARTING',['../group__python__api.html#ga844cbfb2501ece27e8998311aec8c2bd',1,'bot_procman::sheriff']]],
  ['running',['RUNNING',['../group__python__api.html#ga8020feafac0ab719f40288192e3ec2c6',1,'bot_procman::sheriff']]]
];

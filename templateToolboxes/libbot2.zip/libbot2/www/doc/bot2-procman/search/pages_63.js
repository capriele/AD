var searchData=
[
  ['configuration_20files',['Configuration files',['../procman_config_file.html',1,'']]]
];

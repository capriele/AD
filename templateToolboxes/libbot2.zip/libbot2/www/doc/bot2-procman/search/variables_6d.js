var searchData=
[
  ['mem_5frss_5fbytes',['mem_rss_bytes',['../classbot__procman_1_1sheriff_1_1SheriffDeputyCommand.html#a320408c928648f5849924949cf6b0ee0',1,'bot_procman::sheriff::SheriffDeputyCommand']]],
  ['mem_5fvsize_5fbytes',['mem_vsize_bytes',['../classbot__procman_1_1sheriff_1_1SheriffDeputyCommand.html#ada15fe04eeeb48d21a7edc242841e436',1,'bot_procman::sheriff::SheriffDeputyCommand']]]
];

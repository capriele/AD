var searchData=
[
  ['deputy_5finfo_5freceived',['deputy_info_received',['../classbot__procman_1_1sheriff_1_1Sheriff.html#acfc6530f6d7a933ca6e7f4d5fcf4b77f',1,'bot_procman::sheriff::Sheriff']]],
  ['deputy_5fname',['deputy_name',['../classbot__procman_1_1sheriff_1_1SheriffCommandSpec.html#ab77f3c1304d92ad7ddc24dc80e3dc0d5',1,'bot_procman::sheriff::SheriffCommandSpec']]],
  ['desired_5frunid',['desired_runid',['../classbot__procman_1_1sheriff_1_1SheriffDeputyCommand.html#a6e99951db61fa9c39c34431042ac4488',1,'bot_procman::sheriff::SheriffDeputyCommand']]],
  ['disconnect',['disconnect',['../classbot__procman_1_1signal__slot_1_1Signal.html#a50bcc2ca2c1b7a60182a22f6021b7a7c',1,'bot_procman::signal_slot::Signal']]]
];

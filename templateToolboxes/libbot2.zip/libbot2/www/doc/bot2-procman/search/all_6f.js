var searchData=
[
  ['owns_5fcommand',['owns_command',['../classbot__procman_1_1sheriff_1_1SheriffDeputy.html#a807ea4b6c3bf28f306bf3f7918b1ed7e',1,'bot_procman::sheriff::SheriffDeputy']]]
];

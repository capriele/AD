var searchData=
[
  ['is_5fobserver',['is_observer',['../classbot__procman_1_1sheriff_1_1Sheriff.html#ab4d9beef725d401bc100d85b17820156',1,'bot_procman::sheriff::Sheriff']]]
];

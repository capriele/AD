var searchData=
[
  ['move_5fcommand_5fto_5fdeputy',['move_command_to_deputy',['../classbot__procman_1_1sheriff_1_1Sheriff.html#a3ac148220e1ea218b40edc12b17bd9ff',1,'bot_procman::sheriff::Sheriff']]]
];

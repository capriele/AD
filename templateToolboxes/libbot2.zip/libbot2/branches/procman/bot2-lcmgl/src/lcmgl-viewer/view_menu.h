#ifndef __libbot2_bot_vis_view_menu_h__
#define __libbot2_bot_vis_view_menu_h__

#include <bot_vis/bot_vis.h>

#ifdef __cplusplus
extern "C" {
#endif

void setup_view_menu(BotViewer *viewer);

#ifdef __cplusplus
}
#endif

#endif
